#pragma once
#include "SDK.hpp"
using namespace SDK;

//hooking
#include "minhook/MinHook.h"
#pragma comment(lib, "minhook/minhook.lib")

namespace Hooks
{
	AFortPlayerController* Controller;


	LPVOID(*ProcessEvent)(void*, void*, void*);
	LPVOID ProcessEventHook(UObject* Object, UFunction* Function, LPVOID Params)
	{
		std::string FuncName = Function->GetName();

		if (FuncName.find("BP_PlayButton") != std::string::npos)
		{
			Controller->SwitchLevel(L"Athena_Faceoff");


		}
	}
}
