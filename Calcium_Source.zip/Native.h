#pragma once
#include "SDK.hpp"
using namespace SDK;

namespace Native
{
	void(*UWorld_NotifyControlMessage)(UWorld* World, UNetConnection* NetConnection, uint8_t a3, void* a4);
	__int64(*WelcomePlayer)(UWorld* This, UNetConnection* NetConnection);
	APlayerController* (*SpawnPlayActor)(UWorld* a1, UPlayer* a2, ENetRole a3, FURL a4, void* a5, FString& Src, uint8_t a7);
	void (*TickFlush)(UNetDriver*, float DeltaSeconds);
	void (*AddNetworkActor)(UWorld*, AActor*);
	static __int64 (*ServerReplicateActor)(UActorChannel*);
	static UChannel* (*CreateChannel)(UNetConnection*, int, bool, int32_t);
	 static __int64 (*SetChannelActor)(UActorChannel*, AActor*);
	 static void (*CallPreReplication)(AActor*, UNetDriver*);
}
