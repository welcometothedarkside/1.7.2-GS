#pragma once
#include "SDK.hpp"
#include "Util.h"
#include "structs.h"
#include "Native.h"
using namespace SDK;

namespace Replicator //I wish UFortReplicationGraph existed :( - Parrot
{
	UNetDriver* NetDriver;
	UNetConnection* NetConnection;
	UGameplayStatics* GamePlayStatics;

	enum EConnectionState
	{
		USOCK_Invalid = 0,
		USOCK_Closed = 1,
		USOCK_Pending = 2,
		USOCK_Open = 3,
	};

	void PrepConnection(const float DeltaSeconds) //https://github.com/EpicGames/UnrealEngine/blob/4.16/Engine/Source/Runtime/Engine/Private/NetworkDriver.cpp#L2501
	{
		int NumClientsToTick = NetDriver->ClientConnections.Num();

		bool bFoundReadyConnection = false;
		for (__int32 ConnIdx = 0; ConnIdx < NetDriver->ClientConnections.Num(); ConnIdx++)
		{
			UNetConnection* Connection = NetDriver->ClientConnections[ConnIdx];
			if (Connection);


			// Handle not ready channels.
			AActor* OwningActor = Connection->OwningActor;
			if (OwningActor != NULL && EConnectionState::USOCK_Pending && (Connection->Driver->Time - Connection->LastReceiveTime < 1.5f))
			{
				// the view target is what the player controller is looking at OR the owning actor itself when using beacons
				Connection->ViewTarget = Connection->PlayerController ? Connection->PlayerController->GetViewTarget() : OwningActor;

				for (__int32 ChildIdx = 0; ChildIdx < Connection->Children.Num(); ChildIdx++)
				{
					UNetConnection* Child = Connection->Children[ChildIdx];
					APlayerController* ChildPlayerController = Child->PlayerController;
					if (ChildPlayerController != NULL)
					{
						Child->ViewTarget = ChildPlayerController->GetViewTarget();
					}
					else
					{
						Child->ViewTarget = NULL;
					}
				}
			}
			else
			{
				Connection->ViewTarget = NULL;
				for (__int32 ChildIdx = 0; ChildIdx < Connection->Children.Num(); ChildIdx++)
				{
					Connection->Children[ChildIdx]->ViewTarget = NULL;
				}
			}
		}
	}
	std::vector<FNetworkObjectInfo*> PrivateObjectList;

	std::vector<Structs::FNetworkObjectInfo*>& GetNetworkObjectList()
	{
		return PrivateObjectList;
	}

	UActorChannel* FindChannel(AActor* Actor, UNetConnection* Connection)
	{
		for (int i = 0; i < Connection->OpenChannels.Num(); i++)
		{
			auto Channel = Connection->OpenChannels[i];

			if (Channel && Channel->Class)
			{
				if (Channel->Class == UActorChannel::StaticClass())
				{
					if (((UActorChannel*)Channel)->Actor == Actor)
						return ((UActorChannel*)Channel);
				}
			}
		}

		return NULL;
	}

	void BuildConsiderList(std::vector<FNetworkObjectInfo*>& OutConsiderList, const float ServerTickTime)
	{
		auto World = NetDriver->World;

		if (!World)
			return;

		static UKismetMathLibrary* MathLib = (UKismetMathLibrary*)UKismetMathLibrary::StaticClass();

		auto TimeSeconds = GamePlayStatics->STATIC_GetTimeSeconds(World);

		for (auto ActorInfo : GetNetworkObjectList())
		{
			if (!ActorInfo)
			{
				continue;
			}

			if (!ActorInfo->bPendingNetUpdate && TimeSeconds <= ActorInfo->NextUpdateTime)
				continue;

			auto Actor = ActorInfo->Actor;

			if (!Actor || Actor->RemoteRole == ENetRole::ROLE_None || Actor->bActorIsBeingDestroyed)
				continue;
			if (Actor->NetDormancy == ENetDormancy::DORM_Initial && Actor->bNetStartup)
				continue;
			if (Actor->Name.ComparisonIndex != 0)
			{
				Native::CallPreReplication(Actor, NetDriver);
				OutConsider.push_back(ActorInfo);
			}
		}
	}

	bool IsNetRelevantFor(AActor* Actor, const TArray<FNetViewer>& ConnectionViewers)
	{
		for (int32_t viewerIdx = 0; viewerIdx < ConnectionViewers.Num(); viewerIdx++)
		{
			if (IsNetRelevantFor(Actor, ConnectionViewers[viewerIdx].InViewer, ConnectionViewers[viewerIdx].ViewTarget, ConnectionViewers[viewerIdx].ViewLocation))
			{
				return true;
			}
		}

		return false;
	}

	bool TickFlush(UNetDriver* NetDriver, float DeltaSeconds)
	{
		if (!NetDriver)
		{
			return;
		}
		auto Flush = Native::ServerReplicateActor;

		return TickFlush(NetDriver, DeltaSeconds);
	}
}
