#pragma once

// Fortnite (1.8) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Athena_IND_5x5_Factory_b_271.Athena_IND_5x5_Factory_b_C
// 0x0000 (0x03A0 - 0x03A0)
class AAthena_IND_5x5_Factory_b_C : public AFortLevelScriptActor
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Athena_IND_5x5_Factory_b_271.Athena_IND_5x5_Factory_b_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
