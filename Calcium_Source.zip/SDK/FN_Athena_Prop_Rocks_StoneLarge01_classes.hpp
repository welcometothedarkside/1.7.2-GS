#pragma once

// Fortnite (1.8) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Athena_Prop_Rocks_StoneLarge01.Athena_Prop_Rocks_StoneLarge01_C
// 0x0000 (0x0FD0 - 0x0FD0)
class AAthena_Prop_Rocks_StoneLarge01_C : public ABuildingProp
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Athena_Prop_Rocks_StoneLarge01.Athena_Prop_Rocks_StoneLarge01_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
