#pragma once

// Fortnite (1.8) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Athena_REM_3x3_Shack_a_154.Athena_REM_3x3_Shack_a_C
// 0x0000 (0x03A0 - 0x03A0)
class AAthena_REM_3x3_Shack_a_C : public AFortLevelScriptActor
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Athena_REM_3x3_Shack_a_154.Athena_REM_3x3_Shack_a_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
